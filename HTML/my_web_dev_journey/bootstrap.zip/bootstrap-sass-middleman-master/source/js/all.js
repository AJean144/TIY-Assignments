//= require vendor/jquery.min
//= require vendor/bootstrap.min
//= require_tree ./vendor
//= require scripts